import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../models/models.dart';

class HighlightPainter extends CustomPainter {
  final List<Highlight> highlights;
  final double scale;
  final bool isCurrent;

  HighlightPainter({
    required this.highlights,
    required this.scale,
    this.isCurrent = false,
  });

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save(); // Save current canvas state
    canvas.scale(scale, scale); // Hardware-accelerated global scaling

    for (var h in highlights) {
      // 1. Smart Text Highlights
      if (h.type == HighlightType.text && h.rects != null) {
        final paint = Paint()
          ..style = PaintingStyle.fill
          ..color = h.color.withOpacity(0.3);

        for (final rect in h.rects!) {
          canvas.drawRect(rect, paint); // Scaled natively
        }
        continue;
      }

      // 2. Vector Shapes (Arrow, Rect, Circle)
      if (h.type == HighlightType.arrow ||
          h.type == HighlightType.rectangle ||
          h.type == HighlightType.circle) {
        if (h.path.length < 2) continue;

        final p1 = h.path.first; // Unscaled original coordinates
        final p2 = h.path.last;

        final paint = Paint()
          ..color = h.color
          ..style = PaintingStyle.stroke
          ..strokeWidth = h
              .strokeWidth // Scaled natively
          ..strokeCap = StrokeCap.round;

        if (h.type == HighlightType.rectangle) {
          canvas.drawRect(Rect.fromPoints(p1, p2), paint);
        } else if (h.type == HighlightType.circle) {
          canvas.drawOval(Rect.fromPoints(p1, p2), paint);
        } else if (h.type == HighlightType.arrow) {
          canvas.drawLine(p1, p2, paint);

          final dx = p2.dx - p1.dx;
          final dy = p2.dy - p1.dy;
          final angle = math.atan2(dy, dx);
          const arrowHeadLength = 15.0; // Fixed size, natively scaled
          const arrowHeadAngle = 0.5;

          final leftX =
              p2.dx - arrowHeadLength * math.cos(angle - arrowHeadAngle);
          final leftY =
              p2.dy - arrowHeadLength * math.sin(angle - arrowHeadAngle);
          canvas.drawLine(p2, Offset(leftX, leftY), paint);

          final rightX =
              p2.dx - arrowHeadLength * math.cos(angle + arrowHeadAngle);
          final rightY =
              p2.dy - arrowHeadLength * math.sin(angle + arrowHeadAngle);
          canvas.drawLine(p2, Offset(rightX, rightY), paint);
        }
        continue;
      }

      // 3. Freehand Pen & Highlights (Using Cached Path)
      if (h.path.isEmpty) continue;

      final paint = Paint()
        ..color = h.type == HighlightType.pen
            ? h.color
            : h.color.withOpacity(0.4)
        ..style = PaintingStyle.stroke
        ..strokeWidth = h.strokeWidth
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round;

      // BOOM: Zero loop iterations, zero math, instant render
      canvas.drawPath(h.cachedPath, paint);
    }

    canvas.restore(); // Restore canvas state to prevent scaling bleed
  }

  @override
  bool shouldRepaint(covariant HighlightPainter oldDelegate) {
    // Only repaint if the number of highlights changes or scale changes dramatically.
    // For perfect drawing (live), we might need true, but for scrolling performance,
    // we rely on the parent RepaintBoundary to cache the result.
    return oldDelegate.highlights != highlights ||
        oldDelegate.scale != scale ||
        oldDelegate.isCurrent != isCurrent;
  }
}
