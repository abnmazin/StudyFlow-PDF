import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:provider/provider.dart';
import '../../models/models.dart';
import '../../providers/app_state.dart';

class StudyFlowRightPanel extends StatelessWidget {
  final ToolType activeTool;
  final Color activeColor;
  final double strokeWidth;
  final double fontSize;
  final bool isBold;
  final int activeTabIndex;
  final bool isDarkMode;
  final PdfItem? activePdf;
  final PdfViewerController pdfController;
  final ValueChanged<ToolType> onToolChanged;
  final ValueChanged<Color> onColorChanged;
  final ValueChanged<double> onStrokeWidthChanged;
  final ValueChanged<double> onFontSizeChanged;
  final ValueChanged<bool> onBoldChanged;
  final ValueChanged<int> onTabChanged;

  const StudyFlowRightPanel({
    super.key,
    required this.activeTool,
    required this.activeColor,
    required this.strokeWidth,
    required this.fontSize,
    required this.isBold,
    required this.activeTabIndex,
    required this.isDarkMode,
    required this.activePdf,
    required this.pdfController,
    required this.onToolChanged,
    required this.onColorChanged,
    required this.onStrokeWidthChanged,
    required this.onFontSizeChanged,
    required this.onBoldChanged,
    required this.onTabChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 320, // Wider for Chat UI
      decoration: BoxDecoration(
        color: isDarkMode ? const Color(0xFF0F172A) : const Color(0xFFF8FAFC),
        border: Border(
          left: BorderSide(
            color: isDarkMode
                ? const Color(0xFF334155)
                : const Color(0xFFE2E8F0),
            width: 1.5,
          ),
        ),
      ),
      child: Column(
        children: [
          // --- TAB BAR ---
          Container(
            decoration: BoxDecoration(
              color: isDarkMode ? const Color(0xFF1E293B) : Colors.white,
              border: Border(
                bottom: BorderSide(
                  color: isDarkMode
                      ? const Color(0xFF334155)
                      : const Color(0xFFE2E8F0),
                ),
              ),
            ),
            child: Row(
              children: [
                _buildPanelTab(0, LucideIcons.settings, 'Tools'),
                _buildPanelTab(1, LucideIcons.bot, 'AI Chat'),
                _buildPanelTab(2, LucideIcons.languages, 'Translate'),
              ],
            ),
          ),

          // --- TAB CONTENT ---
          Expanded(
            child: IndexedStack(
              index: activeTabIndex,
              children: [
                // TAB 0: TOOLS (Legacy Logic Preserved)
                SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Dynamic Title
                      Row(
                        children: [
                          Icon(
                            [
                                  ToolType.cursor,
                                  ToolType.arrow,
                                  ToolType.rectangle,
                                  ToolType.circle,
                                ].contains(activeTool)
                                ? LucideIcons.mousePointer2
                                : activeTool == ToolType.pen
                                ? LucideIcons.penTool
                                : activeTool == ToolType.highlight
                                ? LucideIcons.highlighter
                                : activeTool == ToolType.text
                                ? LucideIcons.type
                                : LucideIcons.settings,
                            size: 20,
                            color: const Color(0xFF64748B),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            [
                                  ToolType.cursor,
                                  ToolType.arrow,
                                  ToolType.rectangle,
                                  ToolType.circle,
                                ].contains(activeTool)
                                ? 'Read & Shapes'
                                : '${activeTool.name[0].toUpperCase()}${activeTool.name.substring(1)} Properties',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: isDarkMode
                                  ? Colors.white
                                  : const Color(0xFF1E293B),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),

                      // SHAPE SELECTOR (For Read/Cursor Mode)
                      if ([
                        ToolType.cursor,
                        ToolType.arrow,
                        ToolType.rectangle,
                        ToolType.circle,
                      ].contains(activeTool)) ...[
                        const Text(
                          'Tool Mode',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: Color(0xFF64748B),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            _buildShapeSelectorBtn(
                              LucideIcons.mousePointer2,
                              ToolType.cursor,
                              'Pointer',
                            ),
                            _buildShapeSelectorBtn(
                              LucideIcons.arrowUpRight,
                              ToolType.arrow,
                              'Arrow',
                            ),
                            _buildShapeSelectorBtn(
                              LucideIcons.square,
                              ToolType.rectangle,
                              'Rectangle',
                            ),
                            _buildShapeSelectorBtn(
                              LucideIcons.circle,
                              ToolType.circle,
                              'Circle',
                            ),
                          ],
                        ),
                        const SizedBox(height: 24),
                      ],

                      // Text Tool Properties (Preserved)
                      if (activeTool == ToolType.text) ...[
                        const Text(
                          'Font Size',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: Color(0xFF64748B),
                          ),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          child: SliderTheme(
                            data: SliderTheme.of(context).copyWith(
                              trackHeight: 4,
                              thumbShape: const RoundSliderThumbShape(
                                enabledThumbRadius: 8,
                              ),
                              overlayShape: const RoundSliderOverlayShape(
                                overlayRadius: 16,
                              ),
                              activeTrackColor: const Color(0xFF3B82F6),
                              inactiveTrackColor: const Color(0xFFE2E8F0),
                              thumbColor: const Color(0xFF2563EB),
                            ),
                            child: Slider(
                              value: fontSize,
                              min: 10.0,
                              max: 48.0,
                              onChanged: onFontSizeChanged,
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Bold',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                                color: Color(0xFF64748B),
                              ),
                            ),
                            Switch(
                              value: isBold,
                              onChanged: onBoldChanged,
                              activeTrackColor: const Color(0xFF3B82F6),
                            ),
                          ],
                        ),
                        const SizedBox(height: 24),
                      ],

                      // Stroke Width & Color (Preserved)
                      if ([
                        ToolType.highlight,
                        ToolType.pen,
                        ToolType.text,
                        ToolType.arrow,
                        ToolType.rectangle,
                        ToolType.circle,
                      ].contains(activeTool)) ...[
                        if (activeTool != ToolType.text) ...[
                          const Text(
                            'Stroke Width',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          const SizedBox(height: 12),
                          SizedBox(
                            width: double.infinity,
                            child: SliderTheme(
                              data: SliderTheme.of(context).copyWith(
                                trackHeight: 4,
                                thumbShape: const RoundSliderThumbShape(
                                  enabledThumbRadius: 8,
                                ),
                                overlayShape: const RoundSliderOverlayShape(
                                  overlayRadius: 16,
                                ),
                                activeTrackColor: const Color(0xFF3B82F6),
                                inactiveTrackColor: const Color(0xFFE2E8F0),
                                thumbColor: const Color(0xFF2563EB),
                              ),
                              child: Slider(
                                value: strokeWidth,
                                min: 1.0,
                                max: 20.0,
                                onChanged: onStrokeWidthChanged,
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),
                        ],

                        const Text(
                          'Color',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: Color(0xFF64748B),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Wrap(
                          spacing: 12,
                          runSpacing: 12,
                          children:
                              [
                                    const Color(0xFFFEF08A), // Yellow
                                    const Color(0xFFBBF7D0), // Green
                                    const Color(0xFFBFDBFE), // Blue
                                    const Color(0xFFFBCFE8), // Pink
                                    const Color(0xFFDDD6FE), // Purple
                                    const Color(0xFFFECACA), // Red
                                    const Color(0xFF000000), // Black
                                    const Color(0xFFFFFFFF), // White
                                  ]
                                  .map(
                                    (c) => GestureDetector(
                                      onTap: () => onColorChanged(c),
                                      child: Container(
                                        width: 32,
                                        height: 32,
                                        decoration: BoxDecoration(
                                          color: c,
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                            color: activeColor == c
                                                ? const Color(0xFF3B82F6)
                                                : const Color(0xFFE2E8F0),
                                            width: activeColor == c ? 2 : 1,
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Colors.black.withOpacity(
                                                0.05,
                                              ),
                                              blurRadius: 4,
                                              offset: const Offset(0, 2),
                                            ),
                                          ],
                                        ),
                                        child: activeColor == c
                                            ? const Center(
                                                child: Icon(
                                                  LucideIcons.check,
                                                  size: 16,
                                                  color: Color(0xFF3B82F6),
                                                ),
                                              )
                                            : null,
                                      ),
                                    ),
                                  )
                                  .toList(),
                        ),
                      ] else if (!activeTool.toString().contains('cursor') &&
                          !activeTool.toString().contains('arrow') &&
                          !activeTool.toString().contains('rectangle') &&
                          !activeTool.toString().contains('circle'))
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.only(top: 32),
                            child: Text(
                              'No properties available\nfor this tool',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Color(0xFF94A3B8)),
                            ),
                          ),
                        ),

                      // Bookmarks Section (Preserved)
                      const SizedBox(height: 32),
                      const Divider(color: Color(0xFFE2E8F0)),
                      const SizedBox(height: 16),
                      const Text(
                        'Bookmarks',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      const SizedBox(height: 12),
                      if (activePdf != null && activePdf!.bookmarks.isNotEmpty)
                        ...activePdf!.bookmarks.map((bookmark) {
                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            elevation: 1,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                              side: const BorderSide(color: Color(0xFFE2E8F0)),
                            ),
                            child: InkWell(
                              onTap: () {
                                if (pdfController.isReady) {
                                  pdfController.goToPage(
                                    pageNumber: bookmark.page,
                                  );
                                }
                              },
                              borderRadius: BorderRadius.circular(8),
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Row(
                                  children: [
                                    const Icon(
                                      LucideIcons.bookmark,
                                      size: 16,
                                      color: Color(0xFF3B82F6),
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            bookmark.name,
                                            style: const TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500,
                                              color: Color(0xFF1E293B),
                                            ),
                                          ),
                                          Text(
                                            'Page ${bookmark.page}',
                                            style: const TextStyle(
                                              fontSize: 12,
                                              color: Color(0xFF94A3B8),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    IconButton(
                                      icon: const Icon(
                                        LucideIcons.trash2,
                                        size: 16,
                                        color: Color(0xFFDC2626),
                                      ),
                                      onPressed: () {
                                        context
                                            .read<AppProvider>()
                                            .deleteBookmark(
                                              activePdf!.id,
                                              bookmark.id,
                                            );
                                      },
                                      tooltip: 'Delete Bookmark',
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        })
                      else
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.only(top: 16),
                            child: Text(
                              'No bookmarks yet',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Color(0xFF94A3B8)),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),

                // TAB 1: AI ASSISTANT
                _buildAIPanelPlaceholder(),

                // TAB 2: TRANSLATE
                _buildTranslatePanelPlaceholder(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPanelTab(int index, IconData icon, String label) {
    final isActive = activeTabIndex == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => onTabChanged(index),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: isActive
                ? (isDarkMode
                      ? const Color(0xFF334155)
                      : const Color(0xFFE0E7FF))
                : Colors.transparent,
            border: Border(
              bottom: BorderSide(
                color: isActive ? const Color(0xFF6366F1) : Colors.transparent,
                width: 2,
              ),
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 18,
                color: isActive
                    ? const Color(0xFF6366F1)
                    : const Color(0xFF94A3B8),
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                  color: isActive
                      ? const Color(0xFF6366F1)
                      : const Color(0xFF64748B),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Helper method for shape selector buttons in right panel
  Widget _buildShapeSelectorBtn(
    IconData icon,
    ToolType toolValue,
    String tooltip,
  ) {
    final isSelected = activeTool == toolValue;
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: () => onToolChanged(toolValue),
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: isSelected
                ? const Color(0xFFE0E7FF) // Indigo 100
                : const Color(0xFFF1F5F9), // Slate 100
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: isSelected
                  ? const Color(0xFF818CF8) // Indigo 400
                  : Colors.transparent,
              width: 1.5,
            ),
          ),
          child: Icon(
            icon,
            size: 20,
            color: isSelected
                ? const Color(0xFF4F46E5) // Indigo 600
                : const Color(0xFF64748B), // Slate 500
          ),
        ),
      ),
    );
  }

  Widget _buildAIPanelPlaceholder() => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(LucideIcons.bot, size: 48, color: Colors.grey[300]),
        const SizedBox(height: 16),
        const Text(
          "AI Assistant Ready",
          style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold),
        ),
      ],
    ),
  );

  Widget _buildTranslatePanelPlaceholder() => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(LucideIcons.languages, size: 48, color: Colors.grey[300]),
        const SizedBox(height: 16),
        const Text(
          "Translation Ready",
          style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold),
        ),
      ],
    ),
  );
}
