import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_math_fork/flutter_math.dart';

class DraggableTextWidget extends StatefulWidget {
  final String content;
  final Color color;
  final double fontSize;
  final bool isBold;
  final double scale;
  final VoidCallback onTap;
  final ValueChanged<Offset> onDragEnd;
  final bool enableDrag;
  final bool isEditing;
  final void Function(String text, PointerDownEvent? event) onEditComplete;

  const DraggableTextWidget({
    super.key,
    required this.content,
    required this.color,
    required this.fontSize,
    required this.isBold,
    required this.scale,
    required this.onTap,
    required this.onDragEnd,
    required this.enableDrag,
    this.isEditing = false,
    required this.onEditComplete,
  });

  @override
  State<DraggableTextWidget> createState() => _DraggableTextWidgetState();
}

class _DraggableTextWidgetState extends State<DraggableTextWidget> {
  Offset _offset = Offset.zero;
  late TextEditingController _controller;
  late FocusNode _focusNode;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.content);
    _focusNode = FocusNode();
  }

  @override
  void didUpdateWidget(covariant DraggableTextWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isEditing && !oldWidget.isEditing) {
      _controller.text = widget.content;
      _focusNode.requestFocus();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // 1. Fixing Spacebar Scrolling (Event Bubbling)
    if (widget.isEditing) {
      return Material(
        color: Colors.transparent,
        child: IntrinsicWidth(
          child: Focus(
            onKeyEvent: (node, event) {
              if (event.logicalKey == LogicalKeyboardKey.space) {
                return KeyEventResult.skipRemainingHandlers;
              }
              return KeyEventResult.ignored;
            },
            child: TextField(
              controller: _controller,
              focusNode: _focusNode,
              autofocus: true,
              maxLines: null,
              minLines: 1,
              style: TextStyle(
                color: widget.color,
                fontSize: widget.fontSize * widget.scale,
                fontWeight: widget.isBold ? FontWeight.bold : FontWeight.normal,
              ),
              decoration: const InputDecoration(
                border: InputBorder.none,
                hintText: 'Type...',
                isDense: true,
                contentPadding: EdgeInsets.zero,
              ),
              onTapOutside: (event) =>
                  widget.onEditComplete(_controller.text, event),
              onSubmitted: (val) => widget.onEditComplete(val, null),
            ),
          ),
        ),
      );
    }

    // 2. Implement Inline LaTeX Parsing (Mixed Text & Math)
    final parts = widget.content.split(r'$$');
    final children = <Widget>[];

    for (int i = 0; i < parts.length; i++) {
      final part = parts[i];
      if (part.isEmpty) continue;

      // If index is odd, it's inside $$, so treat as Math
      final isMath = i % 2 != 0;

      if (isMath) {
        children.add(
          Math.tex(
            part,
            textStyle: TextStyle(
              color: widget.color,
              fontSize: widget.fontSize * widget.scale,
              fontWeight: widget.isBold ? FontWeight.bold : FontWeight.normal,
            ),
            onErrorFallback: (e) => Text(
              '\$\$$part\$\$',
              style: TextStyle(
                color: Colors.red,
                fontSize: widget.fontSize * widget.scale,
                fontWeight: widget.isBold ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
        );
      } else {
        children.add(
          Text(
            part,
            style: TextStyle(
              color: widget.color,
              fontSize: widget.fontSize * widget.scale,
              fontWeight: widget.isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        );
      }
    }

    if (children.isEmpty) {
      children.add(
        Text(
          'Tap to edit',
          style: TextStyle(
            color: widget.color,
            fontSize: widget.fontSize * widget.scale,
            fontWeight: widget.isBold ? FontWeight.bold : FontWeight.normal,
            fontStyle: FontStyle.italic,
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: widget.onTap,
      onPanUpdate: widget.enableDrag
          ? (details) {
              setState(() {
                _offset += details.delta;
              });
            }
          : null,
      onPanEnd: widget.enableDrag
          ? (details) {
              widget.onDragEnd(_offset);
              setState(() {
                _offset = Offset.zero;
              });
            }
          : null,
      child: Transform.translate(
        offset: _offset,
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.8),
            border: Border.all(color: widget.color, width: 1),
            borderRadius: BorderRadius.circular(4),
          ),
          padding: const EdgeInsets.all(4),
          child: Wrap(
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 2,
            runSpacing: 2,
            children: children,
          ),
        ),
      ),
    );
  }
}
