import 'package:pdfrx/pdfrx.dart';
import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:flutter/services.dart';
import 'package:printing/printing.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart' as sf_pdf;
import 'dart:io';
import 'dart:typed_data';

import '../providers/app_state.dart';
import '../models/models.dart';
import 'viewer_components/viewer_toolbar.dart';
import 'viewer_components/viewer_right_panel.dart';
import '../painters/highlight_painter.dart';
import 'draggable_text_widget.dart';

class PDFViewerWidget extends StatefulWidget {
  const PDFViewerWidget({super.key});

  @override
  State<PDFViewerWidget> createState() => _PDFViewerWidgetState();
}

class _PDFViewerWidgetState extends State<PDFViewerWidget> {
  late PdfViewerController _pdfController;
  int? _lastModified;
  String? _currentPdfId;

  bool _isDarkMode = false;
  bool _isRightPanelOpen = false;
  int _rightPanelTabIndex = 0; // 0: Tools, 1: AI, 2: Translate
  static const ColorFilter _invertFilter = ColorFilter.matrix(<double>[
    -1,
    0,
    0,
    0,
    255,
    0,
    -1,
    0,
    0,
    255,
    0,
    0,
    -1,
    0,
    255,
    0,
    0,
    0,
    1,
    0,
  ]);

  ToolType _tool =
      ToolType.cursor; // 'cursor', 'highlight', 'eraser', 'pen', 'comment'
  Color _color = const Color(0xFFFEF08A); // yellow-200
  double _strokeWidth = 5.0;
  double _fontSize = 14.0;
  bool _isBold = false;
  // _activePointerCount removed - using native onScale gesture

  // Current drawing state
  List<Offset>? _currentPath;
  int _currentPage = -1;
  bool _isProcessing = false; // Processing lock

  String? _editingCommentId;

  final FocusNode _searchFocusNode = FocusNode(); // NEW: Focus node for search
  PdfTextSearcher? _textSearcher;
  bool _isSearchVisible = false;
  PdfTextSelection? _textSelection;

  @override
  void initState() {
    super.initState();
    _pdfController = PdfViewerController();
    _pdfController.addListener(_onControllerChanged);
  }

  void _onControllerChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _pdfController.removeListener(_onControllerChanged);

    _searchFocusNode.dispose(); // Dispose node
    _textSearcher?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // PERFORMANCE: Use read instead of watch to prevent full rebuilds
    // Only rebuild when activePdf changes using Selector
    final app = context.read<AppProvider>();
    final pdf = context.select<AppProvider, PdfItem?>((app) => app.activePdf);

    // Strict Controller Cycle Management
    if (pdf != null) {
      if (_currentPdfId == null) {
        // First load
        _currentPdfId = pdf.id;
        _lastModified = pdf.lastModified;
      } else if (_currentPdfId != pdf.id || _lastModified != pdf.lastModified) {
        // Detected change or modification - FORCE RESET
        _pdfController.removeListener(_onControllerChanged);
        // _pdfController.dispose(); // Not available in pdfrx controller
        _pdfController = PdfViewerController();
        _pdfController.addListener(_onControllerChanged);
        _currentPdfId = pdf.id;
        _lastModified = pdf.lastModified;
        // Optionally reset processing lock to be safe
        _isProcessing = false;
        _textSearcher = null;
        _isSearchVisible = false;
        _textSelection = null;
      }
    }

    return CallbackShortcuts(
      bindings: _editingCommentId != null || pdf == null
          ? <ShortcutActivator, VoidCallback>{}
          : {
              const SingleActivator(LogicalKeyboardKey.keyH): () =>
                  setState(() => _tool = ToolType.highlight),
              const SingleActivator(LogicalKeyboardKey.keyE): () =>
                  setState(() => _tool = ToolType.eraser),
              const SingleActivator(LogicalKeyboardKey.keyP): () =>
                  setState(() => _tool = ToolType.pen),
              const SingleActivator(LogicalKeyboardKey.keyT): () =>
                  setState(() => _tool = ToolType.text),
              const SingleActivator(LogicalKeyboardKey.escape): () =>
                  setState(() => _tool = ToolType.cursor),
              const SingleActivator(LogicalKeyboardKey.keyV): () =>
                  setState(() => _tool = ToolType.cursor),
              const SingleActivator(
                LogicalKeyboardKey.keyP,
                control: true,
              ): () =>
                  _showPrintDialog(pdf),
              const SingleActivator(
                LogicalKeyboardKey.keyF,
                control: true,
              ): () => setState(() {
                if (_textSearcher != null) _isSearchVisible = true;
              }),
              const SingleActivator(
                LogicalKeyboardKey.keyL,
                control: true,
              ): () {
                app.toggleSidebar();
                _forcePdfRelayout();
              },
              const SingleActivator(
                LogicalKeyboardKey.keyR,
                control: true,
              ): () {
                setState(() => _isRightPanelOpen = !_isRightPanelOpen);
                _forcePdfRelayout();
              },
            },
      child: Focus(
        autofocus: true,
        child: Column(
          children: [
            // 1. Toolbar (Top)
            StudyFlowToolbar(
              activeTool: _tool,
              isRightPanelOpen: _isRightPanelOpen,
              isDarkMode: _isDarkMode,
              isSearchVisible: _isSearchVisible,
              activePdf: pdf,
              pdfController: _pdfController,
              onToolChanged: (t) {
                setState(() => _tool = t);
                // Also open panel if needed for certain tools
                if (!_isRightPanelOpen &&
                    (t == ToolType.cursor ||
                        t == ToolType.arrow ||
                        t == ToolType.rectangle ||
                        t == ToolType.circle)) {
                  setState(() => _isRightPanelOpen = true);
                  _forcePdfRelayout();
                }
              },
              onToggleRightPanel: () {
                setState(() => _isRightPanelOpen = !_isRightPanelOpen);
                _forcePdfRelayout();
              },
              onToggleDarkMode: () =>
                  setState(() => _isDarkMode = !_isDarkMode),
              onToggleSearch: () {
                setState(() {
                  _isSearchVisible = !_isSearchVisible;
                  if (_isSearchVisible) {
                    Future.delayed(const Duration(milliseconds: 100), () {
                      _searchFocusNode.requestFocus();
                    });
                  }
                });
              },
              onPrint: _showPrintDialog,
              onAddPage: _addPage,
              onDeletePage: _deleteCurrentPage,
              onAddBookmark: _showAddBookmarkDialog,
            ),

            // 2. Main Content Area (Viewer + Right Panel)
            Expanded(
              child: Row(
                children: [
                  // Viewer Area
                  Expanded(
                    child: Stack(
                      children: [
                        // Background & PDF View
                        Container(
                          color: _isDarkMode
                              ? const Color(0xFF0F172A)
                              : const Color(0xFFE2E8F0),
                          child: pdf == null
                              ? _buildNoFilePlaceholder()
                              : (_isDarkMode
                                    ? ColorFiltered(
                                        colorFilter: _invertFilter,
                                        child: _buildPdfViewerCore(pdf),
                                      )
                                    : _buildPdfViewerCore(pdf)),
                        ),

                        // Search Bar Overlay
                        if (_isSearchVisible && pdf != null)
                          Positioned(
                            top: 80,
                            right: 16,
                            child: Card(
                              elevation: 4,
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SizedBox(
                                      width: 200,
                                      child: TextField(
                                        autofocus: true,
                                        decoration: const InputDecoration(
                                          hintText: 'Find...',
                                          border: InputBorder.none,
                                          isDense: true,
                                        ),
                                        onChanged: (val) {
                                          _textSearcher?.startTextSearch(val);
                                        },
                                      ),
                                    ),
                                    IconButton(
                                      icon: const Icon(LucideIcons.chevronUp),
                                      onPressed: () =>
                                          _textSearcher?.goToPrevMatch(),
                                      tooltip: 'Previous',
                                    ),
                                    IconButton(
                                      icon: const Icon(LucideIcons.chevronDown),
                                      onPressed: () =>
                                          _textSearcher?.goToNextMatch(),
                                      tooltip: 'Next',
                                    ),
                                    IconButton(
                                      icon: const Icon(LucideIcons.x),
                                      onPressed: () {
                                        _textSearcher?.resetTextSearch();
                                        setState(
                                          () => _isSearchVisible = false,
                                        );
                                      },
                                      tooltip: 'Close',
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),

                        // Text Selection Menu
                        if (_textSelection != null)
                          Positioned(
                            bottom: 32,
                            left: 0,
                            right: 0,
                            child: Center(
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.1),
                                      blurRadius: 10,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 8,
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    ...[
                                      const Color(0xFFFEF08A), // Yellow
                                      const Color(0xFFBBF7D0), // Green
                                      const Color(0xFFBFDBFE), // Blue
                                      const Color(0xFFFBCFE8), // Pink
                                      const Color(0xFFDDD6FE), // Purple
                                    ].map(
                                      (c) => GestureDetector(
                                        onTap: () => _addTextHighlight(c),
                                        child: Container(
                                          width: 24,
                                          height: 24,
                                          margin: const EdgeInsets.only(
                                            right: 12,
                                          ),
                                          decoration: BoxDecoration(
                                            color: c,
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color: const Color(0xFFE2E8F0),
                                              width: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: 1,
                                      height: 24,
                                      color: const Color(0xFFE2E8F0),
                                      margin: const EdgeInsets.only(right: 8),
                                    ),
                                    IconButton(
                                      icon: const Icon(LucideIcons.x, size: 20),
                                      onPressed: () async {
                                        if (_textSelection
                                            is PdfTextSelectionDelegate) {
                                          await (_textSelection
                                                  as PdfTextSelectionDelegate)
                                              .clearTextSelection();
                                        }
                                        if (mounted)
                                          setState(() => _textSelection = null);
                                      },
                                      tooltip: 'Clear Selection',
                                      color: const Color(0xFF64748B),
                                      padding: EdgeInsets.zero,
                                      constraints: const BoxConstraints(
                                        minWidth: 32,
                                        minHeight: 32,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),

                        // Vertical Slider
                        if (_pdfController.isReady &&
                            _pdfController.pages.length > 1)
                          Positioned(
                            right: 12,
                            top: 100,
                            bottom: 100,
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.04),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: RotatedBox(
                                quarterTurns: 1,
                                child: SliderTheme(
                                  data: SliderTheme.of(context).copyWith(
                                    trackHeight: 4,
                                    thumbShape: const RoundSliderThumbShape(
                                      enabledThumbRadius: 6,
                                    ),
                                    overlayShape: const RoundSliderOverlayShape(
                                      overlayRadius: 14,
                                    ),
                                    activeTrackColor: const Color(0xFF94A3B8),
                                    inactiveTrackColor: Colors.transparent,
                                    thumbColor: const Color(0xFF64748B),
                                  ),
                                  child: Slider(
                                    min: 1.0,
                                    max: _pdfController.pages.length.toDouble(),
                                    value:
                                        (_pdfController.pageNumber
                                                    ?.toDouble() ??
                                                1.0)
                                            .clamp(
                                              1.0,
                                              _pdfController.pages.length
                                                  .toDouble(),
                                            ),
                                    onChanged: (val) {
                                      setState(() {});
                                      _pdfController.goToPage(
                                        pageNumber: val.toInt(),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),

                  // 3. Right Panel (Side-by-Side)
                  if (_isRightPanelOpen)
                    StudyFlowRightPanel(
                      activeTool: _tool,
                      activeColor: _color,
                      strokeWidth: _strokeWidth,
                      fontSize: _fontSize,
                      isBold: _isBold,
                      activeTabIndex: _rightPanelTabIndex,
                      isDarkMode: _isDarkMode,
                      activePdf: pdf,
                      pdfController: _pdfController,
                      onToolChanged: (t) => setState(() => _tool = t),
                      onColorChanged: (c) {
                        setState(() => _color = c);
                        if (_tool == ToolType.text) _updateCurrentEditingText();
                      },
                      onStrokeWidthChanged: (v) =>
                          setState(() => _strokeWidth = v),
                      onFontSizeChanged: (v) {
                        setState(() => _fontSize = v);
                        if (_tool == ToolType.text) _updateCurrentEditingText();
                      },
                      onBoldChanged: (v) {
                        setState(() => _isBold = v);
                        if (_tool == ToolType.text) _updateCurrentEditingText();
                      },
                      onTabChanged: (i) =>
                          setState(() => _rightPanelTabIndex = i),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPdfViewerCore(PdfItem pdf) {
    return PdfViewer.file(
      pdf.path,
      key: ValueKey(pdf.path),
      controller: _pdfController,

      params: PdfViewerParams(
        // 2. RESOURCE PROTECTION
        // Cap max zoom to prevent memory spikes (4000x4000px textures).
        maxScale: 4.0,
        minScale: 0.5,

        // 3. SMOOTH SCROLL PHYSICS
        scrollPhysics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),

        // 4. SMART OVERLAYS (Optimized)
        pageOverlaysBuilder: (context, pageRect, page) {
          // Use the RepaintBoundary here too if annotations are heavy
          return [
            RepaintBoundary(
              child: _buildPageOverlay(context, pageRect, page, pdf),
            ),
          ];
        },

        // 5. MEMORY MANAGEMENT
        // Remove the loading banner to prevent layout thrashing
        loadingBannerBuilder: (context, bytesDownloaded, totalBytes) =>
            const SizedBox.shrink(),

        // 6. INTERACTION TUNING
        enableKeyboardNavigation:
            _editingCommentId == null && !_isSearchVisible,

        // Keep existing callbacks...
        onViewerReady: (document, controller) {
          if (mounted) {
            setState(() {
              _isProcessing = false;
              _textSearcher ??= PdfTextSearcher(_pdfController)
                ..addListener(_onControllerChanged);
            });
          }
        },
        onPageChanged: (page) {
          context.read<AppProvider>().updatePdfScroll(pdf.id, pageNumber: page);
          if (mounted) setState(() {});
        },
        textSelectionParams: PdfTextSelectionParams(
          onTextSelectionChange: (selection) async {
            if (!mounted) return;
            setState(() => _textSelection = selection);
            try {
              final ranges = await selection.getSelectedTextRanges();
              if (mounted && ranges.isEmpty) {
                setState(() => _textSelection = null);
              }
            } catch (_) {}
          },
        ),
      ),
      initialPageNumber: pdf.lastPage ?? 1,
    );
  }

  Widget _buildNoFilePlaceholder() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Icon(LucideIcons.upload, size: 48, color: Color(0xFFCBD5E1)),
          SizedBox(height: 16),
          Text(
            'No PDF Selected',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Color(0xFF64748B),
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Select a file from the sidebar to view',
            style: TextStyle(fontSize: 14, color: Color(0xFF94A3B8)),
          ),
        ],
      ),
    );
  }

  void _addPage(PdfItem pdf) {
    if (_isProcessing) return;
    setState(() => _isProcessing = true);

    // Add after current page
    int targetPage = 1;
    if (_pdfController.isReady && _pdfController.pageNumber != null) {
      targetPage = _pdfController.pageNumber!;
    } else {
      targetPage = pdf.lastPage ?? 1;
    }
    context.read<AppProvider>().addPage(pdf.id, insertAtIndex: targetPage);
  }

  void _deleteCurrentPage(PdfItem pdf) {
    if (_isProcessing) return;

    // Secure controller access with strict checks
    int pageToDelete = 1;
    if (_pdfController.isReady && _pdfController.pageNumber != null) {
      pageToDelete = _pdfController.pageNumber!;
    } else {
      pageToDelete = pdf.lastPage ?? 1;
    }

    // Show confirmation
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Page?'),
        content: Text(
          'Are you sure you want to delete page $pageToDelete? This cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              setState(() => _isProcessing = true);
              // Page numbers in controller are 1-based, our API expects 0-based index
              context.read<AppProvider>().deletePage(pdf.id, pageToDelete - 1);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _handlePanStart(Offset position, PdfPage page, double scale) {
    if (_tool == ToolType.cursor || _tool == ToolType.text)
      return; // Text handled by onTapUp
    if (_tool == ToolType.eraser) {
      _eraseAt(position / scale, page.pageNumber);
      return;
    }

    // VECTOR SHAPES: Initialize with start point
    setState(() {
      _currentPath = [position / scale];
      _currentPage = page.pageNumber;
    });
  }

  void _handlePanUpdate(Offset position, PdfPage page, double scale) {
    if (_tool == ToolType.cursor || _tool == ToolType.text) return;
    if (_tool == ToolType.eraser) {
      _eraseAt(position / scale, page.pageNumber);
    } else {
      if (_currentPath != null) {
        setState(() {
          // VECTOR SHAPES: Use 2-point paths (start + current end)
          if (_tool == ToolType.arrow ||
              _tool == ToolType.rectangle ||
              _tool == ToolType.circle) {
            // Replace the end point for shapes
            if (_currentPath!.length == 1) {
              _currentPath!.add(position / scale);
            } else {
              _currentPath![1] = position / scale;
            }
          } else {
            // Freehand drawing: add all points
            _currentPath!.add(position / scale);
          }
        });
      }
    }
  }

  void _handlePanEnd(PdfItem pdf) {
    if ((_tool == ToolType.highlight ||
            _tool == ToolType.pen ||
            _tool == ToolType.arrow ||
            _tool == ToolType.rectangle ||
            _tool == ToolType.circle) &&
        _currentPath != null) {
      // Determine highlight type
      HighlightType type;
      if (_tool == ToolType.pen) {
        type = HighlightType.pen;
      } else if (_tool == ToolType.arrow) {
        type = HighlightType.arrow;
      } else if (_tool == ToolType.rectangle) {
        type = HighlightType.rectangle;
      } else if (_tool == ToolType.circle) {
        type = HighlightType.circle;
      } else {
        type = HighlightType.highlight;
      }

      final highlight = Highlight(
        path: List.from(_currentPath!),
        color: _color,
        page: _currentPage,
        strokeWidth: _strokeWidth,
        type: type,
      );

      context.read<AppProvider>().addHighlight(pdf.id, highlight);

      setState(() {
        _currentPath = null;
        _currentPage = -1;
      });
    }
  }

  void _eraseAt(Offset pt, int pageNumber) {
    final app = context.read<AppProvider>();
    final pdf = app.activePdf;
    if (pdf == null) return;
    const double hitRadius = 20.0;
    List<Highlight> toRemove = [];

    for (var h in pdf.highlights) {
      if (h.page != pageNumber) continue;
      bool hit = false;

      // إذا كان تظليلاً ذكياً للنصوص
      if (h.type == HighlightType.text && h.rects != null) {
        for (var r in h.rects!) {
          // توسيع منطقة اللمس قليلاً لتسهيل المسح
          if (r.inflate(hitRadius).contains(pt)) {
            hit = true;
            break;
          }
        }
      }
      // إذا كان تظليلاً حراً أو قلماً
      else {
        for (var p in h.path) {
          if ((p - pt).distance < hitRadius) {
            hit = true;
            break;
          }
        }
      }

      if (hit) toRemove.add(h);
    }

    for (var h in toRemove) {
      app.removeHighlight(pdf.id, h);
    }
  }

  void _addTextAt(Offset pt, int pageNumber) {
    if (_isProcessing) return;

    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final comment = PdfComment(
      id: id,
      page: pageNumber,
      position: pt, // Assumed unscaled ID passed from caller
      content: '',
      date: DateTime.now(),
      color: _color,
      fontSize: _fontSize,
      isBold: _isBold,
    );

    final app = context.read<AppProvider>();
    if (app.activePdf == null) return;

    app.addComment(app.activePdf!.id, comment);
    setState(() => _editingCommentId = comment.id);
  }

  void _updateCurrentEditingText() {
    if (_editingCommentId == null) return;
    final app = context.read<AppProvider>();
    final pdf = app.activePdf;
    if (pdf == null) return;

    try {
      final comment = pdf.comments.firstWhere((c) => c.id == _editingCommentId);
      final updatedComment = comment.copyWith(
        color: _color,
        fontSize: _fontSize,
        isBold: _isBold,
      );
      app.updateComment(pdf.id, comment, updatedComment);
    } catch (e) {
      debugPrint('Error updating comment style: $e');
    }
  }

  void _addTextHighlight(Color color) async {
    if (_textSelection == null) return;

    final app = context.read<AppProvider>();
    final pdf = app.activePdf;
    if (pdf == null) return;

    try {
      final ranges = await _textSelection!.getSelectedTextRanges();
      final selectionsByPage = <int, List<Rect>>{};

      for (final range in ranges) {
        final pageNumber = range.pageNumber;
        final page = _pdfController
            .document
            .pages[pageNumber - 1]; // Ensure document is loaded

        if (!selectionsByPage.containsKey(pageNumber)) {
          selectionsByPage[pageNumber] = [];
        }

        for (final fragment in range.enumerateFragmentBoundingRects()) {
          final rect = fragment.bounds.toRect(page: page);
          selectionsByPage[pageNumber]!.add(rect);
        }
      }

      for (final entry in selectionsByPage.entries) {
        final highlight = Highlight(
          path: [], // Empty path for text highlights
          color: color,
          page: entry.key,
          type: HighlightType.text,
          rects: entry.value,
        );
        app.addHighlight(pdf.id, highlight);
      }

      if (_textSelection is PdfTextSelectionDelegate) {
        await (_textSelection as PdfTextSelectionDelegate).clearTextSelection();
      }
      if (mounted) setState(() => _textSelection = null);
    } catch (e) {
      debugPrint('Error adding text highlight: $e');
    }
  }

  Widget _buildPageOverlay(
    BuildContext context,
    Rect pageRect,
    PdfPage page,
    PdfItem pdf,
  ) {
    final scale = pageRect.width / page.width;
    final ignoring = _tool == ToolType.cursor;

    Widget overlay = IgnorePointer(
      ignoring: ignoring,
      child: Stack(
        children: [
          // Highlights & Pen
          CustomPaint(
            size: Size(pageRect.width, pageRect.height),
            painter: HighlightPainter(
              highlights: pdf.highlights
                  .where((h) => h.page == page.pageNumber)
                  .toList(),
              scale: scale,
            ),
          ),

          // Current Drawing
          if (_currentPage == page.pageNumber && _currentPath != null)
            CustomPaint(
              size: Size(pageRect.width, pageRect.height),
              painter: HighlightPainter(
                highlights: [
                  Highlight(
                    path: _currentPath!,
                    color: _color,
                    page: page.pageNumber,
                    strokeWidth: _strokeWidth,
                    type: _tool == ToolType.pen
                        ? HighlightType.pen
                        : HighlightType.highlight,
                  ),
                ],
                scale: scale,
                isCurrent: true,
              ),
            ),

          if (!ignoring)
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                // Using Scale gesture to natively detect multi-touch (pointerCount)
                onScaleStart: (details) {
                  // MULTI-TOUCH NEURO-LINK: Immediately cancel drawing on multi-touch
                  if (details.pointerCount > 1) {
                    setState(() {
                      _tool = ToolType.cursor;
                      _currentPath = null;
                      _currentPage = -1;
                    });
                    return;
                  }
                  _handlePanStart(details.localFocalPoint, page, scale);
                },
                onScaleUpdate: (details) {
                  // MULTI-TOUCH NEURO-LINK: Stop all operations on multi-touch
                  if (details.pointerCount > 1) {
                    return;
                  }
                  _handlePanUpdate(details.localFocalPoint, page, scale);
                },
                onScaleEnd: (details) {
                  // If we ended a valid single-finger stroke
                  _handlePanEnd(pdf);
                },
                onTapUp: (details) {
                  if (_tool == ToolType.text) {
                    _addTextAt(details.localPosition / scale, page.pageNumber);
                  }
                },
              ),
            ),

          // Text (Comments) - Must be on TOP to receive hits!
          ...pdf.comments.where((c) => c.page == page.pageNumber).map((c) {
            return Positioned(
              left: c.position.dx * scale,
              top: c.position.dy * scale,
              child: DraggableTextWidget(
                content: c.content,
                color: c.color,
                fontSize: c.fontSize,
                isBold: c.isBold,
                scale: scale,
                isEditing: c.id == _editingCommentId,
                onEditComplete: (newText, event) {
                  // CRITICAL FIX: If user tapped the Right Panel, DO NOT close editing.
                  if (event != null && _isRightPanelOpen) {
                    final screenWidth = MediaQuery.of(context).size.width;
                    const rightPanelWidth = 250.0;
                    final tapX = event.position.dx;
                    // If tap is within the right panel area (right side of screen)
                    if (tapX > screenWidth - rightPanelWidth) {
                      return;
                    }
                  }

                  setState(() => _editingCommentId = null);
                  if (newText.trim().isEmpty) {
                    context.read<AppProvider>().removeComment(pdf.id, c);
                  } else {
                    context.read<AppProvider>().updateComment(
                      pdf.id,
                      c,
                      c.copyWith(content: newText),
                    );
                  }
                },
                onTap: () {
                  if (_tool == ToolType.text) {
                    setState(() {
                      _editingCommentId = c.id;
                      _fontSize = c.fontSize;
                      _isBold = c.isBold;
                      _color = c.color;
                    });
                  } else if (_tool == ToolType.eraser) {
                    context.read<AppProvider>().removeComment(pdf.id, c);
                  }
                },
                onDragEnd: (offset) {
                  if (_tool == ToolType.text || _tool == ToolType.cursor) {
                    final newPos = c.position + offset / scale;
                    context.read<AppProvider>().updateComment(
                      pdf.id,
                      c,
                      c.copyWith(position: newPos),
                    );
                  }
                },
                enableDrag:
                    !(_tool == ToolType.eraser) && (c.id != _editingCommentId),
              ),
            );
          }),
        ],
      ),
    );

    // Apply double-inversion to keep highlight colors original
    if (_isDarkMode) {
      overlay = ColorFiltered(colorFilter: _invertFilter, child: overlay);
    }

    // PERFORMANCE SHIELD: Wrap entire overlay in RepaintBoundary to cache rendering
    return RepaintBoundary(child: overlay);
  }

  void _forcePdfRelayout() {
    if (!_pdfController.isReady) return;
    final currentPage = _pdfController.pageNumber ?? 1;
    // VIEWPORT ADAPTER: Wait 300ms for sidebar animation to complete
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted && _pdfController.isReady) {
        _pdfController.goToPage(pageNumber: currentPage);
      }
    });
  }

  void _showPrintDialog(PdfItem pdf) async {
    String pageRange = 'All'; // All, Odd, Even
    bool reverseOrder = false;

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Print Options'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Page Range',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF64748B),
                ),
              ),
              const SizedBox(height: 8),
              RadioListTile<String>(
                dense: true,
                title: const Text('All Pages'),
                value: 'All',
                groupValue: pageRange,
                onChanged: (val) => setDialogState(() => pageRange = val!),
              ),
              RadioListTile<String>(
                dense: true,
                title: const Text('Odd Pages'),
                value: 'Odd',
                groupValue: pageRange,
                onChanged: (val) => setDialogState(() => pageRange = val!),
              ),
              RadioListTile<String>(
                dense: true,
                title: const Text('Even Pages'),
                value: 'Even',
                groupValue: pageRange,
                onChanged: (val) => setDialogState(() => pageRange = val!),
              ),
              if (pageRange == 'Even') ...[
                const SizedBox(height: 12),
                CheckboxListTile(
                  dense: true,
                  title: const Text('Reverse Order (for manual duplex)'),
                  value: reverseOrder,
                  onChanged: (val) => setDialogState(() => reverseOrder = val!),
                ),
              ],
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _printPdf(
                  pdf,
                  pageRange: pageRange,
                  reverseOrder: reverseOrder,
                );
              },
              child: const Text('Print'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _printPdf(
    PdfItem pdf, {
    String pageRange = 'All',
    bool reverseOrder = false,
  }) async {
    try {
      final file = File(pdf.path);
      if (!await file.exists()) return;

      final bytes = await file.readAsBytes();
      final document = sf_pdf.PdfDocument(inputBytes: bytes);
      final totalPages = document.pages.count;

      // Determine which pages to print
      List<int> pageIndices = [];
      for (int i = 0; i < totalPages; i++) {
        final pageNumber = i + 1;
        if (pageRange == 'All') {
          pageIndices.add(i);
        } else if (pageRange == 'Odd' && pageNumber % 2 == 1) {
          pageIndices.add(i);
        } else if (pageRange == 'Even' && pageNumber % 2 == 0) {
          pageIndices.add(i);
        }
      }

      // Reverse order if requested
      if (reverseOrder) {
        pageIndices = pageIndices.reversed.toList();
      }

      // Create a new document with selected pages
      final newDocument = sf_pdf.PdfDocument();
      for (final pageIndex in pageIndices) {
        newDocument.pages.add().graphics.drawPdfTemplate(
          document.pages[pageIndex].createTemplate(),
          const Offset(0, 0),
        );
      }

      final filteredBytes = await newDocument.save();
      document.dispose();
      newDocument.dispose();

      await Printing.layoutPdf(
        onLayout: (format) async => Uint8List.fromList(filteredBytes),
        name: pdf.name,
      );
    } catch (e) {
      debugPrint('Print error: $e');
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Print error: $e')));
      }
    }
  }

  void _showAddBookmarkDialog(PdfItem pdf) {
    final controller = TextEditingController();
    final currentPage = _pdfController.pageNumber ?? 1;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Bookmark'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Page $currentPage',
              style: const TextStyle(fontSize: 14, color: Color(0xFF64748B)),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: controller,
              autofocus: true,
              decoration: const InputDecoration(
                hintText: 'Bookmark name',
                border: OutlineInputBorder(),
              ),
              onSubmitted: (_) {
                if (controller.text.trim().isNotEmpty) {
                  context.read<AppProvider>().addBookmark(
                    pdf.id,
                    controller.text.trim(),
                    currentPage,
                  );
                  Navigator.of(context).pop();
                }
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              if (controller.text.trim().isNotEmpty) {
                context.read<AppProvider>().addBookmark(
                  pdf.id,
                  controller.text.trim(),
                  currentPage,
                );
                Navigator.of(context).pop();
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  // Removed _buildBottomBar and _showPageJumpDialog for inline UI
}
