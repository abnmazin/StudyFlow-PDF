import 'package:flutter/material.dart';
import 'enums.dart';

class Highlight {
  final List<Offset> path;
  final Color color;
  final int page;
  final double strokeWidth;
  final HighlightType type;
  final List<Rect>? rects;

  Highlight({
    required this.path,
    required this.color,
    required this.page,
    this.strokeWidth = 5.0,
    this.type = HighlightType.highlight,
    this.rects,
  });

  Path? _cachedPath;
  Path get cachedPath {
    if (_cachedPath != null) return _cachedPath!;
    final p = Path();
    if (path.isNotEmpty) {
      p.moveTo(path.first.dx, path.first.dy);
      for (var i = 1; i < path.length; i++) {
        p.lineTo(path[i].dx, path[i].dy);
      }
    }
    _cachedPath = p;
    return p;
  }

  Map<String, dynamic> toJson() => {
    'path': path.map((o) => {'dx': o.dx, 'dy': o.dy}).toList(),
    'color': color.value,
    'page': page,
    'strokeWidth': strokeWidth,
    'type': type.toString(),
    if (rects != null)
      'rects': rects!
          .map((r) => {'L': r.left, 'T': r.top, 'R': r.right, 'B': r.bottom})
          .toList(),
  };

  factory Highlight.fromJson(Map<String, dynamic> json) {
    return Highlight(
      path: (json['path'] as List)
          .map((p) => Offset(p['dx'], p['dy']))
          .toList(),
      color: Color(json['color']),
      page: json['page'],
      strokeWidth: json['strokeWidth'] ?? 5.0,
      type: json['type'] != null
          ? HighlightType.values.firstWhere(
              (e) => e.toString() == json['type'],
              orElse: () => HighlightType.highlight,
            )
          : HighlightType.highlight,
      rects: (json['rects'] as List?)?.map((r) {
        return Rect.fromLTRB(r['L'], r['T'], r['R'], r['B']);
      }).toList(),
    );
  }
  Highlight copyWith({
    List<Offset>? path,
    Color? color,
    int? page,
    double? strokeWidth,
    HighlightType? type,
    List<Rect>? rects,
  }) {
    return Highlight(
      path: path ?? this.path,
      color: color ?? this.color,
      page: page ?? this.page,
      strokeWidth: strokeWidth ?? this.strokeWidth,
      type: type ?? this.type,
      rects: rects ?? this.rects,
    );
  }
}

class PdfComment {
  final String id;
  final int page;
  final Offset position;
  final String content;
  final DateTime date;
  final Color color;
  final double fontSize;
  final bool isBold;

  PdfComment({
    required this.id,
    required this.page,
    required this.position,
    required this.content,
    required this.date,
    this.color = Colors.yellow,
    this.fontSize = 14.0,
    this.isBold = false,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'page': page,
    'dx': position.dx,
    'dy': position.dy,
    'content': content,
    'date': date.toIso8601String(),
    'color': color.value,
    'fontSize': fontSize,
    'isBold': isBold,
  };

  factory PdfComment.fromJson(Map<String, dynamic> json) {
    return PdfComment(
      id: json['id'],
      page: json['page'],
      position: Offset(json['dx'], json['dy']),
      content: json['content'],
      date: DateTime.parse(json['date']),
      color: Color(json['color'] ?? 0xFFFEF08A),
      fontSize: json['fontSize']?.toDouble() ?? 14.0,
      isBold: json['isBold'] ?? false,
    );
  }
  PdfComment copyWith({
    String? id,
    int? page,
    Offset? position,
    String? content,
    DateTime? date,
    Color? color,
    double? fontSize,
    bool? isBold,
  }) {
    return PdfComment(
      id: id ?? this.id,
      page: page ?? this.page,
      position: position ?? this.position,
      content: content ?? this.content,
      date: date ?? this.date,
      color: color ?? this.color,
      fontSize: fontSize ?? this.fontSize,
      isBold: isBold ?? this.isBold,
    );
  }
}

class PdfBookmark {
  final String id;
  final int page;
  final String name;

  PdfBookmark({required this.id, required this.page, required this.name});

  Map<String, dynamic> toJson() => {'id': id, 'page': page, 'name': name};

  factory PdfBookmark.fromJson(Map<String, dynamic> json) {
    return PdfBookmark(id: json['id'], page: json['page'], name: json['name']);
  }
}
