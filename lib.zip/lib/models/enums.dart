enum HighlightType { highlight, pen, text, arrow, rectangle, circle }

enum ToolType { cursor, highlight, pen, text, eraser, arrow, rectangle, circle }
